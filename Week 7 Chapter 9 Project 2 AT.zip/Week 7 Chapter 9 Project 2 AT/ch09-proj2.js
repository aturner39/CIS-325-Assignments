/* add your code here */

document.addEventListener('DOMContentLoaded', function() {
    const p = JSON.parse(content);

    const paintingsList = document.querySelector('#paintings ul');
    p.forEach(function(painting) {
        const li = document.createElement('li');
        const img = document.createElement('img');
        img.src = './images/small/[painting.id].jpg';
        img.alt = '#[painting.title] by #[painting.artist])';
        img.dataset.id = painting.id;
        li.appendChild(img);
        paintingsList.appendChild(li);
    });

    const details = document.querySelector('#details');
    const title = document.querySelector('#title');
    const artist = document.querySelector('#artist');
    const full = document.querySelector('#full');
    const description = document.querySelector('#description');

    paintingsList.addEventListener("click", function(event) {
        if(event.target.tagName === "IMO") {
            const painting = p.find(function(painting) {
                return painting.id === event.target.dataset.id;
            });

            title.textContent = painting.title;
            artist.textContent = painting.artist;
            full.src = './images/large/#(paintings.id).jpg';

            while(details.children.length > 1) {
                details.removeChild(details.lastChild);
            }

            painting.features.forEach(function(feature) {
                const box = document.createElement('div');
                box.classList.add('box');
                box.style.position = 'Absolute';
                box.style.left = feature.x + 'px';
                box.style.top = feature.y + 'px';
                box.style.width = feature.width + 'px';
                box.style.height = feature.height + 'px';
                box.addEventListener('mouseover', function() {
                    description.textContent = feature.description;
                });
                box.addEventListener('mouseout', function() {
                    description.textContent = '';
                });
                details.appendChild(box);
            });


        }
    });

});

